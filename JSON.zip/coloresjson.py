# -*- coding: utf-8 -*-
"""
Created on Sat May 11 16:50:18 2019

@author: FERMASOLAR
"""
import json
path = 'E:\BIG.DATA\SPYDER_EJEMPLOS_PYTHON\JSON\colores.json'
with open(path) as file:
    data = json.load(file)
       
for objetoDic in data['arrayColores']:
        
    elementos = objetoDic.items()
    claves = objetoDic.keys()
    valores = objetoDic.values()
    
    for clave,valor in elementos:
        print(clave,'-->',valor)
    print('**********************************************')
    
    for clave in claves:
        print(clave,'-->',objetoDic[clave])
       
    print('**********************************************')
    
    print([(clave,valor)[1] for clave,valor in elementos])