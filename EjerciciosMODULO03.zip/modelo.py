"""
Crea un conjunto de datos utilizando el siguiente código:

trX = np.linspace(-1, 1, 101)

trY = np.linspace(-1, 1, 101)

for i in range(len(trY)):

trY[i] = math.log(1 + 0.5 * abs(trX[i])) + trX[i] / 3 + np.random.randn() * 0.033

Ahora, utiliza Theano para obtener los parámetros w_0 y w_1 del siguiente modelo:

y = log (1 + wo |x|) + w1 x

utilizando los datos generados anteriormente.
"""
import math
import matplotlib.pyplot as plt
import numpy as np
import theano
import theano.tensor as T
 
trX = np.linspace(-1, 1, 101)
trY = np.linspace(-1, 1, 101)

for i in range(len(trY)):
    trY[i] = math.log(1 + 0.5 * abs(trX[i])) + trX[i] / 3 + np.random.randn() * 0.033

 
X = T.scalar()
Y = T.scalar()

def model(X, w0, w1):
    return T.log(1+w0*abs(X))+w1*X

w0 = theano.shared(np.asarray(0., dtype = theano.config.floatX))
w1 = theano.shared(np.asarray(0., dtype = theano.config.floatX))
modelo = model(X, w0, w1)

cost     = T.mean(T.sqr(modelo - Y))
gradient_w0 = T.grad(cost = cost, wrt = w0)
gradient_w1 = T.grad(cost = cost, wrt = w1)
updates  = [[w0, w0 - gradient_w0 * 0.01], [w1, w1 - gradient_w1 * 0.01]]

train = theano.function(inputs = [X, Y], outputs = cost, updates = updates)

matriz_costes = []
for i in range(25):
    for x, y in zip(trX, trY):
        matriz_costes.append(train(x, y))
    print('En el paso', i, 'el valor de w0 es', w0.get_value(),
           'y w1 es', w1.get_value(), 'con un coste', matriz_costes[i])

plt.plot(matriz_costes)