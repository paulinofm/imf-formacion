# -*- coding: utf-8 -*-
"""
En el archivo auto.csv se encuentran los siguientes datos de diferentes automóviles:

Cilindros
Cilindrada
Potencia
Peso
Aceleración
Año del coche
Origen
Consumo (mpg)
Las unidades de las características de los automóviles no se encuentran en el 
sistema internacional. La variable “origen” es un código que identifica al país 
de origen.

Crea un modelo con él para que se pueda estimar el consumo de un vehículo a partir 
del resto de las variables.
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Lasso
from scipy.stats import uniform as sp_rand
from sklearn.model_selection import RandomizedSearchCV

def cargarDataset():
    return pd.read_csv('auto.csv', sep = ',')

def calculateVIF(data):
    features = list(data.columns)
    num_features = len(features)
    
    model = LinearRegression()
    
    result = pd.DataFrame(index = ['VIF'], columns = features)
    result = result.fillna(0)
    
    for ite in range(num_features):
        x_features = features[:]
        y_feature = features[ite]
        x_features.remove(y_feature)
        
        x = data[x_features]
        y = data[y_feature]
        
        model.fit(x, y)
        
        result[y_feature] = 1/(1 - model.score(data[x_features], data[y_feature]))
    
    return result


def selectDataUsingVIF(data, max_VIF = 5):
    result = data.copy(deep = True)
    
    VIF = calculateVIF(result)
    
    while VIF.as_matrix().max() > max_VIF:
        col_max = np.where(VIF == VIF.as_matrix().max())[1][0]
        features = list(result.columns)
        features.remove(features[col_max])
        result = result[features]
        
        VIF = calculateVIF(result)
        
    return result


def dividir_dataset_train_test(data,target,test_ratio):
    indices_aleatorios = np.random.permutation(len(data))
    test_set_size = int(len(data) * test_ratio)
    test_indices = indices_aleatorios[:test_set_size]
    train_indices = indices_aleatorios[test_set_size:]
    return data.iloc[train_indices],data.iloc[test_indices],target.iloc[train_indices],target.iloc[test_indices]


"""
################### PROGRAMA PRINCIPAL ###################
"""
#fijar semilla de numeros aleatorios en numpy
np.random.seed(48)

autosDF = cargarDataset()
autosDF.head()
autosDF.info(20)
autosDF.hist()
plt.show()


""" Ajuste: todos las caracerísticas excepto mpg y con dummies:origin, model_year y cylinders """  
df2 = pd.concat([autosDF,pd.get_dummies(autosDF['origin'], prefix='origin')],axis=1).drop(['origin'],axis=1)
df2 = pd.concat([df2,pd.get_dummies(df2['model_year'], prefix='model_year')],axis=1).drop(['model_year'],axis=1)
df2 = pd.concat([df2,pd.get_dummies(df2['cylinders'], prefix='cylinders')],axis=1).drop(['cylinders'],axis=1)

df2 = df2.drop(['mpg'],axis=1)
df2.info()
vifdf2 = selectDataUsingVIF(df2,5)
vifdf2.info()

"""variable objetivo"""
target = autosDF['mpg']

"""Creacion de un conjunto de entrenamiento y otro de test"""
train_set , test_set , target_train_set , target_test_set = dividir_dataset_train_test(vifdf2,target,0.33)

print("train_set tamaño:",len(train_set))
print("test_set tamaño:",len(test_set))

"""Modelo Lasso con distintos alfa, con termino independiente o sin el y con el dataframe vifdf2"""
fit_intercept = np.array([True, False])

# Creación del modelo
model = Lasso()

param_grid = dict(alpha = sp_rand(),fit_intercept = fit_intercept)

rsearch = RandomizedSearchCV(estimator = model,
                             param_distributions = param_grid,
                             n_iter = 100,
                             cv = 10,
                             random_state = 1)
fit = rsearch.fit(train_set, target_train_set)

predict = rsearch.fit(test_set, target_test_set)

# Los mejores parametros para el modelo
print('El mejor parámetro en entrenamiento es', fit.best_params_)
print('El mejor score en entrenamiento es', fit.best_score_)

print('----------------------------------------------')
print('El mejor parametro en test es', predict.best_params_)
print('El mejor score en test es', predict.best_score_)

print("Coeficientes:", fit.best_estimator_.coef_)
print("w0:", fit.best_estimator_.intercept_)
print('----------------------------------------------')
print("Coeficientes:", predict.best_estimator_.coef_)
print("w0:", predict.best_estimator_.intercept_)


