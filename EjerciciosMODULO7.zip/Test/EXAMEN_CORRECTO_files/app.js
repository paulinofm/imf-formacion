$(document).foundation();

var widthbotonera = 0;
var boxTooltip;

$(document).ready(function () {
	// tutorias
	$('#toggleFormNewTutoria').on('click', function (ev) {
		ev.preventDefault();
		var $text = $(this).text();
		var labels = $(this).data('toggle').split(" - ");

		$(this).text($text == labels[0] ? labels[1] : labels[0]);

		var $form = $('#formNewTutoria');

		$form.slideToggle(300, function () {
			if ($(this).is(':visible')) {
				$(this).find('input[type="text"]:first').focus();
			}
		});
	});

	$('#newTutoria').on('submit', function (e) {
		e.preventDefault();
		$('#callout-tutoria').removeClass('hide');
	});

	// indicador
	$('.indicadorNeutro__navBtn__handler').on('click', function (e) {
		e.preventDefault();
		var $this = $(this);

		$this.addClass('indicadorNeutro__navBtn__handler--open');
		$this.find('.iNavIndicador').toggleClass('iAula-close iAula-nav-indicador');
		$this.parent().parent().next('.indicadorNeutro__navContent').slideToggle(300, function () {
			if (!$(this).is(":visible")) {
				$this.removeClass('indicadorNeutro__navBtn__handler--open');
			} else {
				$(this).find('input:first').focus();
			}
		});
	});


	// switch para la disponibilidad del alumno
	$('header .switch-paddle').on('click', function () {
		setTimeout(function() {
			var estado = $(this).parent('.switch').find('input').prop('checked');

			$('header .switch input').each(function (i, input) {
				$(input).prop('checked', estado);
			})
		})
	});


	// cerrar notificaciones
	$('.close-dropdown-pane').on('click', function () {
		$(this).parent('.dropdown-pane').foundation('close');
	});


	// tamaño de la botonera
	boxTooltip = $('#tooltipIndice');
	$('.large-version').find('.columns').each(function (index) {
		widthbotonera = widthbotonera + $(this).width()
	});
	botoneraVersion();

	// legacy aula responsive
	mostrarAgenda();
});

$( window ).resize(function() {
	botoneraVersion();
	mostrarAgenda();
});

$("#menu").hover(function() {
	//$('#menu').animate({"left": '+=312'});
	$('#menu').addClass('menuOpen');
}, function() {
	//$('#menu').animate({"left": '-=312'});
	$('#menu').removeClass('menuOpen');
});

	
/*
$('.switch-option').click(function () {
	if(!$(this).hasClass('switch-option-active'))
	{
		$('.switch-option').removeClass('switch-option-active');
		$(this).addClass('switch-option-active');
	}
});

$('.close-dropdown-pane').click(function () {
	$(this).parent('.dropdown-pane').foundation('close');
});

$('[data-toggle]').click(function(evt) {
	evt.preventDefault();
});
*/

function tooltipIndice(description, title) {

	boxTooltip.find('.tooltipIndice-title').text(title)
	boxTooltip.find('.tooltipIndice-description').text(description)
	boxTooltip.show();

	$(this).mousemove(function( e ) {
		boxTooltip.css({
			left:  e.pageX + 14,
			top:   e.pageY + 14
		})
	});
}

function tooltipIndiceOut() {
	boxTooltip.hide();
}

function botoneraVersion() {

	var hw = widthbotonera + 30;
	var bw = $(document).width();

	if(bw < hw ){
		$('body').addClass('small-version');
	} else {
		$('body').removeClass('small-version');
    }

}



/* agenda responsive */
var mobileAgendaVersion = false;

function mostrarAgenda() {
	var currentWidth = $(document).width();
	var mediumWidthAgenda = 700;
	var minwidthAgenda = 640;

	var viewAgenda = $("#checkAgenda").is(':checked');

	// Utiliza las funciones del script jBox.agenda.js
	if (typeof doShowVistaAgenda !== "function" || typeof doShowVistaCalendario !== "function") { 
		// Si no estan definidas el script no realiza ninguna accion
		return;
	}

	if (viewAgenda || currentWidth < mediumWidthAgenda) {

		mobileAgendaVersion = true;
		doShowVistaAgenda();

		if (currentWidth < minwidthAgenda) {
			// Fijar ancho del calendario
			$('.gldp-flatwhite').width(326);
			$('.gldp-flatwhite').css({
				maxWidth: "326px",
				minWidth: "326px",
			});
		} else if (currentWidth < mediumWidthAgenda) {
			// Fijar ancho del calendario
			//$('.gldp-flatwhite').width(256);
			$('.gldp-flatwhite').css({
				maxWidth: "256px",
				minWidth: "256px",
			});
		} else {
			// Fijar ancho del calendario
			//$('.gldp-flatwhite').width(326);
			$('.gldp-flatwhite').css({
				maxWidth: "326px",
				minWidth: "256px",
			});
		}

	} else {
		if (mobileAgendaVersion) {
			doShowVistaCalendario();
			mobileAgendaVersion = false;
		}
	}
}


// collapse indice
'use strict';

(function ($) {
	$.fn.accordionRow = function (opt) {

		var $this = $(this);
		var $header = $this.find('.mainIndice__header');
		var $headerArrow = $this.find('.mainIndice__header .accesoUnidad__arrow');
		var $body = $this.find('.mainIndice__body');
		var options = $.extend({
			actived: false
		}, opt);

		var init = function init() {
			if ($.trim($body.text()) === '') {
				$body.hide();
				$header.removeAttr('tabindex');
				$this.find('.accesoUnidad__arrow').css({ 'visibility': 'hidden'});
			} else {
				listeners();
				if (!options.actived) {
					$body.hide();
				} else {
					$this.addClass('mainIndice__row--opened');
					$this.prev().addClass('mainIndice__row--withoutline');
				}
			}
		};

		var openRow = function openRow() {
			$body.slideToggle(350);
			$this.toggleClass('mainIndice__row--opened');
			$this.prev().toggleClass('mainIndice__row--withoutline');
			$header.blur();
		};

		var listeners = function listeners() {
			$header.find('.accesoUnidad__title > a').on('click', function(event){
				event.stopPropagation();
			});

			//$header.on('click', openRow);
			$headerArrow.on('click', openRow);
			$header.on('keydown', function (ev) {
				if (ev.keyCode === 32 || ev.keyCode === 13) {
					openRow();
				}
			});
		};

		init();
	};

	$.fn.collapseIndex = function (num) {
		var arrActived = Array.prototype.slice.call(arguments, 0);

		return this.each(function () {
			$(this).find('.mainIndice__row:has(.accesoUnidad__number)').each(function (index) {
				var nUnidadEnTexto = parseInt($(this).find('.accesoUnidad__number').text(),10);

				//if (arrActived.indexOf(index) != -1) {
				if (arrActived.indexOf(nUnidadEnTexto) != -1) {
					$(this).accordionRow({ actived: true });
				} else {
					$(this).accordionRow();
				}
			});
		});
	};
})(jQuery);

'use strict';

var avatarStudent = function () {
	var $file,
		$wrap,
		$btn,
		$fieldImageCropped,
		$uploadCroppie,
		$avatarStudent,
		options = {},
		$fieldResult = false;

	function updatePreviewImage(input) {
		if (input.files && input.files[0]) {
			var reader = new FileReader();
			reader.onload = function (e) {
				$wrap.parent().addClass('ready');
				$avatarStudent.addClass('editing');
				$avatarStudent.removeClass('isUnselected');

				$uploadCroppie.croppie('bind', {
					url: e.target.result
				});
			};
			reader.readAsDataURL(input.files[0]);
		}
	}

	function sendImage(ev) {

		$uploadCroppie.croppie('result', {
			type: 'canvas',
			size: 'viewport'
		}).then(function (resp) {
			if (options.inputId) {
				$('#' + options.inputId).val(resp);
			}
			if (typeof options.update === "function") {
				options.update();
			}
			$('#photoAlumn').attr('src', resp);
		});
	}

	function init(opt) {
		options = opt;

		$file = $('#fieldAddAvatar');
		$wrap = $('#preview-photo');
		$btn = $('#sendAvatarStudent');
		$fieldImageCropped = $('#fieldImageCropped');
		$avatarStudent = $('.avatar-student');
		$uploadCroppie = $wrap.croppie({
			viewport: {
				width: 150,
				height: 150
			},
			update: sendImage
		});

		$file.on('change', function () {
			updatePreviewImage(this);
		});
		$btn.on('click', sendImage);
	}


	return {
		init: init
	};
}();


'use strict';

(function () {
	var requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame || window.msRequestAnimationFrame;
	window.requestAnimationFrame = requestAnimationFrame;
})();

function DonutProgress(donut, percent, estatico) {
	this.estatico = estatico || false;
	this.circle = donut.find('.donutProgress__bar');
	this.circleBg = donut.find('.donutProgress__bg');

	var wCircle = parseInt(donut.css('width'));
	var bCircle = parseInt(this.circle.css('stroke-width'));
	var radius = (wCircle - bCircle) / 2;
	var firstTime = true;

	this.circleBg.attr('cx', wCircle / 2);
	this.circleBg.attr('cy', wCircle / 2);
	this.circleBg.attr('r', radius);

	var angle = -97.5;
	var iterator = Math.round(0.75 * percent);

	this.draw = function () {

		angle += 5;
		angle %= 360;
		var radians = angle / 180 * Math.PI;

		var x = Math.ceil((radius + bCircle / 2 + Math.cos(radians) * radius) * 100) / 100;
		var y = Math.ceil((radius + bCircle / 2 + Math.sin(radians) * radius) * 100) / 100;

		if (firstTime === true) {
			var d = this.circle.attr('d') + " M " + x + " " + y;
			firstTime = false;
		} else {
			var d = this.circle.attr('d') + " L " + x + " " + y;
		}

		this.circle.attr('d', d);
		iterator--;

		if (iterator >= 0) {
			if (this.estatico) {
				this.draw();
			} else {
				requestAnimationFrame(this.draw.bind(this));
			}
		} else {
			if (percent > 2) {
				donut.find('.donutProgress__roundEnd').show();
			}
		}
	};
}

$(document).ready(function () {

	var firstTimeInSession = sessionStorage.getItem('aula-session');
	if (!firstTimeInSession) {
		$('body').addClass('firstSession');
		sessionStorage.setItem('aula-session', true);
	}

	$('.donutProgress').each(function (index) {
		var $this = $(this);
		var per = $this.attr('aria-valuenow');

		var $required = $this.find('.progressRequired').data('required');

		if ($required) {
			var grades = $required * 360 / 100;
			var styles = {
				"-webkit-transform": "rotate(" + grades + "deg)",
				"-ms-transform": "rotate(" + grades + "deg)",
				"transform": "rotate(" + grades + "deg)"
			};
			$this.find('.progressRequired').css(styles);
		}

		var html = '<svg preserveAspectRatio="xMidYMid" xmlns:xlink="http://www.w3.org/1999/xlink" id="donutChartSVG' + index + '">';
		html += '<defs><linearGradient id="gradient' + index + '" x1="0" x2="0" y1="0" y2="1">';
		html += '<stop class="gradientStart" offset= "0%" /><stop class="gradientEnd" offset="100%" /></linearGradient ></defs>';
		html += '<circle class="donutProgress__bg" />';
		html += '<rect width="100%" height="100%" class="donutProgress__square" style="fill: url(#gradient' + index + '); mask: url(#clipping' + index + ');" />';
		html += '<marker id="semiCircleEnd' + index + '" markerWidth="1" markerHeight="2" refX="0.02" refY="1" orient="auto">';
		html += '<circle cx="0" cy="1" r=".5" class="donutProgress__roundEnd" style="display:none; stroke: none; fill:#ffffff;" /></marker></defs>';
		html += '<mask id="clipping' + index + '"><path d="M100,100" class="donutProgress__bar" marker-end="url(#semiCircleEnd' + index + ')"/></mask></svg>';

		$this.find('.donutProgress__label').after(html);

		var donutProgress;

		if (firstTimeInSession) {
			donutProgress = new DonutProgress($('#donutChartSVG' + index), parseInt(per), true);
		} else {
			donutProgress = new DonutProgress($('#donutChartSVG' + index), parseInt(per));
		}

		donutProgress.draw();
	});

	// Texto cortado
	var showChar = 400;
	var moreText = "Mostrar m�s";
	var lessText = "Mostrar menos";

	$('.truncate-text').each(function() {
		var content = $(this).html();
		if (content.length > showChar) {
			var c = content.substr(0, showChar);
			$(this).attr({'data-orig': content, 'data-expanded': false});
			$(this).html('<span class="truncate-text__content">' + c + '...</span> <a href="javascript:void(0)" class="truncate-text__btn">' + moreText + '</a>');
		}
	});

	$('.truncate-text__btn').on('click', function() {
		var parent = $(this).parents('.truncate-text');
		var parentContent = $(this).prev('.truncate-text__content');
		var isExpanded = $(parent).attr('data-expanded');

		var content = $(parentContent).html();
		var contentOrig = $(parent).attr('data-orig');

		if (isExpanded == "true") {
			var c = content.substr(0, showChar);
			$(parent).attr('data-expanded', false);
			$(parentContent).html(c + "...");
			$(this).text(moreText);
		} else {
			$(parent).attr('data-expanded', true);
			$(parentContent).html(contentOrig);
			$(this).text(lessText);
		}
	});
});