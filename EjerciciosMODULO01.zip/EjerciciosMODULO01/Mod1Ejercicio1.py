# -*- coding: utf-8 -*-
"""
Created on Thu May 23 10:46:51 2019

@author: PAULINO FERNANDEZ MADRID
"""

import json
import sys

if len(sys.argv) != 3:
    print("Este programa necesita dos parámetros: archivo de sentimientos + archivo de tweets")
    sys.exit(0)


def tiene_contenido(obj_dic):
    return 'text' in obj_dic

def calcula_sentimiento_tweet(dict_palabras,obj_tweet):
    try:      
        sentimiento_tweet = 0
        lista_palabras_tweet = obj_tweet['text'].lower().split()
        for palabra in lista_palabras_tweet:
            if palabra in dict_palabras:
                sentimiento_tweet += dict_palabras[palabra]
        return 'EL SIGUIENTE TWEET: \"{0}\" TIENE UN SENTIMIENTO ASOCIADO DE {1}'.format(obj_tweet['text'],sentimiento_tweet)
    except:
        print('ERROR AL CALCULAR EL SENTIMIENTO DE LA LINEA-->{0}'.format(obj_tweet['text']))
        raise

ficherotweets = open(sys.argv[2],"r",encoding="utf-8")

lista_json = [json.loads(linea) for linea in ficherotweets if tiene_contenido(json.loads(linea))]

ficherotweets.close()

sentimientos = open(sys.argv[1])
valores = {}
for linea in sentimientos:
    termino , valor = linea.split("\t")
    valores[termino] = int(valor)


for elementos in lista_json:
    print(calcula_sentimiento_tweet(valores,elementos))

