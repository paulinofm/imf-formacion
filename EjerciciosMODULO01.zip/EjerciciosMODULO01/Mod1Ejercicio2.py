# -*- coding: utf-8 -*-
"""
Created on Fri May 24 01:32:28 2019

@author: Paulino Fernandez Madrid
"""
import json
import sys

if len(sys.argv) != 3:
    print("Este programa necesita dos parámetros: archivo de sentimientos + archivo de tweets")
    sys.exit(0)

def tiene_contenido(obj_dic):
    return 'text' in obj_dic

def calcula_sentimiento_tweet(dict_palabras,obj_tweet):
    try:      
        sentimiento_tweet = 0
        lista_palabras_tweet = obj_tweet['text'].lower().split()
        for palabra in lista_palabras_tweet:
            if palabra in dict_palabras:
                sentimiento_tweet += dict_palabras[palabra]
        return sentimiento_tweet
    except:
        print('ERROR AL CALCULAR EL SENTIMIENTO DE LA LINEA-->{0}'.format(obj_tweet['text']))
        raise

def calcula_sentimiento_otras_palabras(dict_palabras,obj_tweet):
    sentimiento_tweet = calcula_sentimiento_tweet(dict_palabras,obj_tweet)
    lista_palabras_tweet = obj_tweet['text'].lower().split()
    for palabra in lista_palabras_tweet:
        if palabra not in dict_palabras:
            print('\"{0}\":{1}'.format(palabra,sentimiento_tweet))

sentimientos = open(sys.argv[1])
valores = {}
for linea in sentimientos:
    termino , valor = linea.split("\t")
    valores[termino] = int(valor)

ficherotweets = open(sys.argv[2],"r",encoding="utf-8")
lista_json = [json.loads(linea) for linea in ficherotweets if tiene_contenido(json.loads(linea))]
ficherotweets.close()

for elementos in lista_json:
    calcula_sentimiento_otras_palabras(valores,elementos)