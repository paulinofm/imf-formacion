# -*- coding: utf-8 -*-
"""
Editor de Spyder

Este es un archivo temporal.
"""
import csv
from datetime import datetime
path = 'E:\BIG.DATA\SPYDER_EJEMPLOS_PYTHON\CSV\google_stock_data.csv'
fichero = open(path,newline='')
lectorcsv = csv.reader(fichero)
lineacabecera = next(lectorcsv) #cabecera del fichero
#datos = [fila for fila in lectorcsv]



print(lineacabecera)
print('*************************************************************')  

datos = []
idx=0
for fila in lectorcsv:
    #fecha = datetime.strptime(fila[0],'%m/%d/%Y')
    fecha = fila[0]
    precio_apertura = float(fila[1])
    precio_alto = float(fila[2])
    precio_bajo = float(fila[3])
    precio_cierre  = float(fila[4])
    volumen = float(fila[5])
    precio_ajustado = float(fila[6])
    
    datos.append([fecha,precio_apertura,precio_alto,precio_bajo,precio_cierre,volumen,precio_ajustado])
  
    print(datos[idx])
    idx+=1
    
    

