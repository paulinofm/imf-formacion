library(data.table)
library(missForest)
library(caret)
library(ROCR)
# Leemos los datos del CSV en R
crx.data  <- read.csv(file="/home/fermasolar/Documentos/MODULO02/Ejercicios/CASO_FINAL_crx.data", na.strings=c("?"," ") ,header=FALSE, sep="," )

hist(as.numeric(crx.data$V16)-1)

crx.data$V16 <- as.numeric(crx.data$V16)-1

plot(crx.data[,c(2,3,8,11,14,15)], col=crx.data$V16)

crx.data <- missForest(crx.data)$ximp

set.seed(257)
trainIndex <- createDataPartition(crx.data$V16, p=0.70, list=FALSE)
dataTrain <- crx.data[ trainIndex,]
dataTest <- crx.data[-trainIndex,]
dim(dataTest)

model <- glm(V16 ~.,family=binomial(link='logit'),data=dataTrain)
summary(model)

probabilities <- predict(model, newdata = dataTest[,-16], type='response')
dim(probabilities)
predictions <- ifelse(probabilities > 0.5,'1','0')
dim(predictions)
table(predictions, dataTest$V16)

misClasificError <- mean(predictions != dataTest$V16)
print(paste('Accuracy',1-misClasificError))

copy_dataTest <- data.frame(dataTest)
dim(copy_dataTest)
copy_dataTest_pred <- cbind(copy_dataTest, predictions)
copy_dataTest_pred
dim(copy_dataTest_pred)

predicted <- predict(model, newdata=dataTest[,-16], type="response")

pr <- prediction(predicted, dataTest$V16)
prf <- performance(pr, measure = "tpr", x.measure = "fpr")
plot(prf)

auc <- performance(pr, measure = "auc")
auc <- auc@y.values[[1]]
auc

exp(coefficients(model))



