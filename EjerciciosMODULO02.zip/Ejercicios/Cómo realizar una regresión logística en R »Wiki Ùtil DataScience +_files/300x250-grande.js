(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.chico800 = function() {
	this.initialize(img.chico800);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,508,800);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Símbolo15 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ACVCJQgpg1AAhUQgBhSArg2QArg3BDAAQBMAAAqA7IghAZQgSgZgTgKQgUgMgdAAQgwAAgfAsQgfArAABDQAABDAgAsQAfArAwAAQBgAAAAhvIAAgDIhEAAIAAgnIBsAAIAAAlQAABKgnApQgmAng8AAQhEAAgqg3gAinCeIAVghQAuAeA3AAQAtAAAZgZQAYgYAAgpQAAglgXgUQgXgUgqAAQgrAAgjAWIgpgOIAOi2IDUAAIAAAoIixAAIgJB4QAigYAwAAQA9AAAiAgQAfAcAAA0QAABBgnAiQgkAfhAAAQhCAAg0gigAmBCwQgdgOgTgWIAbgbQAoAqAyAAQBaAAAAhLQgBgigYgSQgXgSgpAAIgYAAIAAgjIAZAAQAkAAASgSQASgRAAgfQAAg/hMAAQgsAAggAiIgagbQArgsA8AAQAzAAAgAXQAhAaAAAuQAAA8g0AbQBDAOAABKQABA1gkAeQgjAeg+AAQghAAgigQgAGqC6IAAl0ICJAAQAuAAAbAXQAcAYAAAvQAAA5g2ATQBIASAABKQAABuh6AAgAHUCVIBfAAQBNAAAAhHQAAgjgVgTQgVgTglAAIhdAAgAHUggIBaAAQBAAAAAg7QABg5g+AAIhdAAgApACBIAAhsIhpAAIAAgjIBpAAIAAhsIAnAAIAABsIBpAAIAAAjIhpAAIAABsg");
	this.shape.setTransform(62.2,35.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Símbolo15, new cjs.Rectangle(-6,16,136.3,38.5), null);


(lib.Símbolo12 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AqVE4QgfgoAAg+QAAg/AhgpQAfgpAzAAQA4AAAhAtIgZATQgOgTgOgIQgPgIgWAAQgkAAgXAgQgXAgAAAzQAAAyAXAhQAYAhAkAAQBIAAAAhTIAAgDIgzAAIAAgdIBRAAIAAAcQgBA3gdAfQgcAdgtAAQgzAAgggpgAIIFdIAAkXICpAAIAAAcIiKAAIAABYIBQAAIAAAcIhQAAIAABrICPAAIAAAcgAEbFdIAAkXIBLAAQA5AAAiAhQAjAjABBFQAABIgnAlQgjAhg7AAgAE7FBIApAAQBhAAAAhxQAAg1gYgcQgagdgwAAIgoAAgADPFdIiPjiIAADiIgdAAIAAkXIAeAAICNDlIAAjlIAdAAIAAEXgAgcFdIgYhHIh0AAIgYBHIggAAIBhkXIAiAAIBgEXgAg+D6IgwiTIgwCTIBgAAgAkeFdIg8h3IhCAAIAAB3IgfAAIAAkXIBvAAQAnAAAXATQAZAVAAAnQAAAggSAUQgRAUggAHIA+B5gAmcDKIBKAAQA+AAgBg0QAAg0g4AAIhPAAgAiHikQgMgcgFgSIAADZIgeAAIAAkWIAjAAIBCCnQAQAnADAPIBWjdIAiAAIAAEWIgeAAIAAjZQgEANgNAhIhJCygAFPgaIAVgXQAjAhAoAAQAbAAAQgNQAQgMAAgXQAAgTgNgNQgPgNgmgOQgugQgRgRQgSgSAAgeQAAghAZgTQAXgTAoAAQAvAAAlAeIgUAYQgfgagjAAQgbAAgOANQgNAKAAASQAAASAMAMQAOAMAoAOQAtARASASQASATAAAfQgBAigYAVQgaAWgqAAQg3AAgngmgAEeAHIgYhGIhzAAIgYBGIghAAIBikWIAiAAIBgEWgAD9hbIgwiTIgxCTIBhAAgAk1AHIgYhGIhzAAIgZBGIgfAAIBhkWIAhAAIBhEWgAlWhbIgxiTIgwCTIBhAAgAq1AHIAAkWIAeAAIAAD7ICLAAIAAAbgADAkhIApg/IArAAIg8A/g");
	this.shape.setTransform(69.3,35.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Símbolo12, new cjs.Rectangle(-0.2,0,138.9,70.7), null);


(lib.Símbolo8 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF5900").s().p("AhCArIAdhVIAJAAIgfBVgAhmAeQgJgIgCgOIgLAAIAFgFIAGAAIAAgIIgLAAIAFgFIAGAAQADgPAJgFQAJgHANAAQAGAAAKADIAAAIQgIgDgIAAQgKAAgEADQgHAFgDALIAjAAIgDAFIghAAIAAAIIAcAAIgCAFIgZAAQADALAGAFQAFAFAIAAQAIAAAKgDIAAAJIgDAAQgIACgHAAQgNAAgIgHgABZAdIAFgFQAGAFAHAAQALAAAAgIQAAgCgDgCQgCgCgIgEIgKgFQgDgGAAgEQAAgFADgDQAFgFAHAAQAKAAAHAHIgEAEQgGgFgIABQAAAAgBAAQgBAAAAAAQgBAAAAAAQgBABAAAAQgFACAAACQAAAEAFABIAIAGQAIACADADQAEAFAAAFQAAAIgFAEQgFADgIAAQgKABgIgIgAAzAeQgFgIAAgOQAAgLAFgHQAGgHAKAAQAKAAAFAHQAFAHAAALIAAADIgjAAQAAAKAEAEQAEAFAHgBQAGABAJgFIACAFQgFADgCACIgLABQgJAAgGgGgABRAHQgCgRgNAAQgMAAgCARIAdAAIAAAAgAAhAjIAAgdQAAgKgDgDQgDgDgGAAQgLAAAAAQIAAAdIgIAAIAAgdQAAgQgJAAQgNAAAAAQIAAAdIgHAAIAAgzIAHAAIAAAHQAFgIAJAAQAIAAAFAJQAGgJAJAAQATAAAAAUIAAAgg");
	this.shape.setTransform(78.9,19.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF5900").s().p("ABFDaQDOgSApjJQg6A9hdAAQhMAAgvgoQgygpABhOQgBhSA3gtQA0grBVAAQBUAAAyAvQA2A1AABqQAAB6hBBaQhSBwicAJgABTi5QgiAfAAA0QAAA0AjAdQAiAcA+AAQA+AAAlgdQAjgeABgyQAAgyglggQglghg7AAQg/AAgkAggAl0EGQAGhcAsg8QAhguBWg6QBFguAWgbQAWgaAAgkQAAgpgbgXQgdgYgzAAQhHAAg4AxIgigrQBJg6BaAAQBKAAArAhQAuAkAABEQAAA3geAlQgZAdhNA0QhMA1geAkQgbAggIAsIEWAAIAAA4g");
	this.shape_1.setTransform(29,42);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Símbolo8, new cjs.Rectangle(-8.2,15,99.7,54.1), null);


(lib.Símbolo6 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Al3gYQgJgWgEgOIAACkIgXAAIAAjRIAbAAIAxB+QAMAcADALIBAilIAaAAIAADRIgWAAIAAikQgDALgKAZIg3CFgAIXBOIAQgSQAaAaAdAAQAWAAALgKQAMgJAAgRQAAgOgJgLQgMgJgcgKQgigLgOgOQgNgNAAgXQAAgYASgPQASgOAeAAQAkAAAbAXIgPASQgXgTgbAAQgUAAgLAIQgJAJAAANQAAAOAJAIQAKAKAfAKQAiANANANQANANAAAYQAAAZgSAQQgUARgfAAQgqAAgdgdgAhXBoIAAi8Ig+AAIAAgUICUAAIAAAUIg+AAIAAC8gAH2BoIgSg1IhWAAIgSA1IgZAAIBJjRIAaAAIBIDRgAHdAeIgkhtIglBtIBJAAgADABoIAAjRIA4AAQArAAAZAZQAbAbAAAzQAAA2gdAbQgZAZgtAAgADYBTIAfAAQBJAAAAhUQAAgngTgWQgTgVgkAAIgeAAgACUBoIgSg1IhWAAIgSA1IgZAAIBJjRIAaAAIBIDRgAB7AeIgkhtIglBtIBJAAgAjDBoIAAjRIAXAAIAADRgAnSBoIAAjRIAWAAIAADRgApqBoIAAjRIAXAAIAAC8IBoAAIAAAVgAqiBoIAAjRIAXAAIAADRg");
	this.shape.setTransform(67.5,40.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Símbolo6, new cjs.Rectangle(0,29.6,135.1,21.8), null);


(lib.Símbolo4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAAAwIAKgLQAQAPARAAQANAAAHgFQAIgGgBgKQAAgJgGgGQgGgGgRgGQgVgGgIgIQgIgIAAgOQAAgPALgIQAKgJASAAQAWAAARANIgJALQgPgLgQAAQgMAAgGAFQgGAFAAAIQAAAJAGAFQAGAFASAHQAVAHAIAIQAIAIAAAOQgBAPgKAKQgMAKgTAAQgZAAgSgRgAhUA/IAAh9IBNAAIAAANIg+AAIAAAnIAkAAIAAAMIgkAAIAAAwIBBAAIAAANg");
	this.shape.setTransform(8.5,6.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Símbolo4, new cjs.Rectangle(0,0,16.9,13.1), null);


(lib.Símbolo3 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AEqAvQgOgSAAgdQAAgcAOgSQAPgTAXABQAaAAAPATIgMAJQgGgIgHgEQgHgEgJAAQgRAAgKAPQgLAPAAAWQAAAXALAPQAKAOARAAQASAAANgQIAKAIQgQAWgZAAQgYgBgOgSgAkDAwIAKgLQAQAQARgBQANAAAIgFQAHgGAAgKQAAgKgGgFQgHgGgRgGQgVgGgIgIQgIgJAAgNQAAgQALgIQALgIASAAQAVgBASAOIgJALQgPgMgQAAQgNAAgGAGQgGAEAAAJQAAAIAGAFQAGAFASAHQAWAIAHAHQAIAJAAAOQAAAQgLAJQgLALgUAAQgZAAgSgSgAKwA/Igbg2IgeAAIAAA2IgOAAIAAh+IAyAAQASAAALAIQALAKAAASQAAAPgIAJQgIAIgOADIAcA3gAJ3gCIAiAAQAcAAAAgZQAAgXgaAAIgkAAgAJMA/IgMggIg0AAIgLAgIgPAAIAth+IAPAAIAsB+gAI8ASIgWhCIgWBCIAsAAgAHVA/IAAg7Ig/AAIAAA7IgOAAIAAh+IAOAAIAAA2IA/AAIAAg2IAPAAIAAB+gAD+A/IhBhlIAABlIgOAAIAAh+IAOAAIBBBoIAAhoIANAAIAAB+gACLA/IAAh+IAOAAIAAB+gABmA/IAAg7Ig/AAIAAA7IgPAAIAAh+IAPAAIAAA2IA/AAIAAg2IAOAAIAAB+gAgnA/IgLggIg1AAIgLAgIgOAAIAsh+IAPAAIAtB+gAg2ASIgXhCIgWBCIAtAAgAkZA/IgMggIg0AAIgLAgIgOAAIAsh+IAPAAIAtB+gAkpASIgWhCIgWBCIAsAAgAm1A/Igrh+IAPAAIAkBvIAlhvIAOAAIgrB+gApbA/IAAh+IBNAAIAAANIg+AAIAAAoIAkAAIAAAMIgkAAIAAAxIBBAAIAAAMgAqcA/IAAhxIgmAAIAAgNIBZAAIAAANIglAAIAABxg");
	this.shape.setTransform(66.1,14.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Símbolo3, new cjs.Rectangle(-4.5,7.7,141.4,13.1), null);


(lib.Símbolo2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AHrCEQgOgTAAgcQAAgdAOgTQAPgSAYAAQAXAAAPASQAOATAAAdQAAAcgPATQgOASgYAAQgYABgOgTgAH2AuQgLAOAAAZQAAAXALAPQALAPARAAQAQAAALgPQALgPAAgXQAAgYgLgPQgLgOgRAAQgRAAgKAOgAg1CEQgOgTAAgcQAAgdAOgTQAPgSAYAAQAXAAAOASQAPATAAAdQAAAcgPATQgPASgWAAQgYABgPgTgAgqAuQgLAOAAAZQAAAXALAPQAMAPAQAAQAQAAALgPQAKgPAAgXQAAgYgKgPQgMgOgPAAQgRAAgLAOgAikCFIAJgLQARAPARABQANgBAHgFQAIgGAAgLQAAgJgHgGQgHgFgRgHQgUgHgIgIQgJgIAAgOQAAgPAMgJQALgIASAAQAVAAARAOIgJAKQgOgMgQABQgNAAgGAFQgGAGAAAIQAAAHAFAGQAHAFASAIQAVAHAIAIQAIAIAAAPQAAAQgLAJQgMAKgTAAQgaAAgRgRgAF2CVIAAiAIAiAAQAaAAAPAPQARAQAAAgQAAAhgSAQQgQAPgbABgAGECHIATAAQAsAAAAgyQAAgZgLgNQgMgNgVAAIgTAAgAFZCVIgLghIg1AAIgLAhIgOAAIAsiAIAPAAIAtCAgAFKBnIgWhDIgWBDIAsAAgADjCVIgbg2IgeAAIAAA2IgOAAIAAiAIAyAAQASAAAKAJQAMAJAAASQAAAOgIAKQgIAJgOADIAcA4gACqBRIAiAAQAcAAAAgXQAAgYgaAAIgkAAgAA2CVIAAiAIAuAAQAQAAAJAHQAKAJAAAQQAAATgSAHQAYAGAAAaQAAAlgqABgABECHIAgAAQAaAAAAgXQAAgNgHgGQgHgHgNAAIgfAAgABEBJIAfAAQAWABAAgVQAAgTgVAAIggAAgAkfCVIAAiAIBNAAIAAANIg/AAIAAAoIAlAAIAAANIglAAIAAAwIBCAAIAAAOgAmLCVIAAiAIAiAAQAaAAAPAPQARAQAAAgQAAAhgSAQQgPAPgcABgAl9CHIATAAQAsAAAAgyQAAgZgLgNQgMgNgVAAIgTAAgAnSCVIgbg2IgeAAIAAA2IgOAAIAAiAIAyAAQASAAALAJQALAJAAASQAAAOgIAKQgIAJgOADIAcA4gAoLBRIAiAAQAcAAAAgXQAAgYgaAAIgkAAgAo+CVIAAiAIAPAAIAACAgAAfgkIAJgKQAQAPASAAQANAAAHgGQAHgGAAgKQAAgJgGgGQgHgGgRgGQgVgIgIgHQgIgIAAgOQAAgPALgJQALgJASABQAWAAARANIgJALQgOgMgRAAQgMAAgHAGQgFAFAAAIQAAAIAFAGQAGAFATAHQAVAHAIAJQAIAIAAAOQAAAPgMAKQgLALgUAAQgZAAgRgSgAhKhIIAAhLIAOAAIAABKQAAAqAhAAQAQAAAIgKQAGgKAAgVIAAhLIAOAAIAABKQAAA3gtAAQguAAAAg2gAitglQgOgTAAgcQAAgdAPgSQAPgSAXAAQAZgBAPAVIgLAJQgGgKgHgDQgHgEgKAAQgRAAgKAPQgKAPAAAXQAAAWALAQQAKAPAQAAQAhAAAAgnIAAgBIgXAAIAAgMIAlAAIAAAMQAAAagOAOQgMANgVAAQgXAAgPgTgApFgkIAJgKQAQAPASAAQANAAAHgGQAHgGAAgKQAAgJgGgGQgHgGgRgGQgUgIgJgHQgIgIAAgOQAAgPAMgJQAKgJASABQAWAAARANIgJALQgOgMgRAAQgMAAgGAGQgGAFAAAIQAAAIAFAGQAGAFATAHQAVAHAIAJQAIAIAAAOQAAAPgLAKQgMALgUAAQgZAAgRgSgAE3gUIgLghIg1AAIgLAhIgOAAIAsh/IAPAAIAtB/gAEohCIgWhDIgWBDIAsAAgACigUIAAhzIglAAIAAgMIBZAAIAAAMIglAAIAABzgAk3gUIAAh/IBNAAIAAAMIg+AAIAAApIAkAAIAAAMIgkAAIAAAwIBBAAIAAAOgAl5gUIAAhzIglAAIAAgMIBZAAIAAAMIglAAIAABzgAnegUIAAh/IAOAAIAAB/g");
	this.shape.setTransform(53.1,45.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Símbolo2, new cjs.Rectangle(-5.1,30.7,116.5,30.1), null);


(lib.pacumulables = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_15 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(15).call(this.frame_15).wait(1));

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAQgMIgGgRIAABRIgKAAIAAhoIANAAIAYA+IAHAUIAhhSIANAAIAABoIgLAAIAAhRQgBAFgGAMIgcBCgAI0AnIAHgIQANAMAPAAQAKAAAHgFQAFgEAAgJQAAgIgEgEQgGgFgPgFQgQgFgHgHQgGgHgBgLQAAgNAJgGQAJgIAPAAQASABAOAKIgIAJQgLgJgNAAQgLAAgFAFQgFAEAAAHQAAAHAFADQAFAFAPAFQARAHAHAGQAHAHAAAMQAAAMgKAIQgKAIgPAAQgWAAgNgOgABlAJIAAg9IANAAIAAA9QgBAiAbAAQANAAAHgJQAFgIABgRIAAg9IALAAIAAA9QAAAsglAAQgnAAAAgsgAhXAJIAAg9IAMAAIAAA9QAAAiAbAAQANAAAGgJQAGgIAAgRIAAg9IAMAAIAAA9QAAAsgmAAQgmAAAAgsgAieAmQgMgPAAgXQAAgXAMgPQANgQASAAQAWAAAMARIgJAHQgGgHgFgDQgGgDgIAAQgOAAgJAMQgIANAAASQAAATAJAMQAJAMANAAQAQAAAKgOIAIAHQgNARgVAAQgTAAgMgPgAliAnIAHgIQANAMAPAAQALAAAFgFQAHgEgBgJQAAgIgEgEQgGgFgPgFQgQgFgHgHQgGgHgBgLQAAgNAKgGQAIgIAPAAQASABAOAKIgIAJQgLgJgNAAQgLAAgFAFQgFAEAAAHQAAAHAFADQAEAFAQAFQARAHAHAGQAHAHgBAMQABAMgKAIQgKAIgPAAQgVAAgOgOgAoAAmQgLgPAAgXQAAgXALgPQANgQASAAQAVAAAMARIgJAHQgFgHgFgDQgGgDgIAAQgNAAgKAMQgIANAAASQAAATAJAMQAIAMAOAAQAbAAAAggIAAAAIgSAAIAAgLIAeAAIAAAKQgBAVgKAMQgLAKgRAAQgTAAgMgPgAptAmQgLgPAAgXQAAgXALgPQAMgQATAAQAWAAALARIgJAHQgFgHgFgDQgGgDgIAAQgNAAgKAMQgIANAAASQAAATAJAMQAIAMAOAAQAbAAAAggIAAAAIgTAAIAAgLIAfAAIAAAKQgBAVgKAMQgLAKgRAAQgUAAgLgPgAHwA0IAAhoIA/AAIAAAKIgzAAIAAAhIAeAAIAAAKIgeAAIAAApIA2AAIAAAKgAGpA0IAAhoIAMAAIAABeIAzAAIAAAKgAFbA0IAAhoIAmAAQANAAAHAGQAIAHAAANQAAAQgPAGQAUAEAAAVQAAAfgiAAgAFmAqIAbAAQAWgBgBgTQAAgKgFgGQgHgFgKAAIgaAAgAFmgJIAaAAQARAAABgRQgBgQgQAAIgbAAgAFIA0IgJgaIgsAAIgJAaIgMAAIAkhoIAOAAIAkBogAE7APIgSg2IgTA2IAlAAgAC9A0IAAhoIALAAIAABeIA0AAIAAAKgAi4A0IgJgaIgrAAIgJAaIgNAAIAlhoIANAAIAkBogAjFAPIgSg2IgSA2IAkAAgAlwA0IgJgaIgsAAIgJAaIgMAAIAlhoIANAAIAlBogAl8APIgSg2IgTA2IAlAAgAogA0IAAhoIAMAAIAABog");
	this.shape.setTransform(70.8,10.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAUgMIgHgRIAABRIgLAAIAAhoIAOAAIAYA+IAHAUIAhhSIANAAIAABoIgLAAIAAhRQgBAFgGAMIgcBCgAJLAnIAIgIQANAMAPAAQAKAAAHgFQAFgEABgJQgBgIgEgEQgGgFgOgFQgRgFgHgHQgHgHAAgLQABgNAIgGQAJgIAPAAQASABAOAKIgHAJQgMgJgOAAQgKAAgFAFQgFAEAAAHQAAAHAEADQAGAFAPAFQARAHAHAGQAGAHABAMQAAAMgKAIQgJAIgRAAQgVAAgOgOgABsAJIAAg9IALAAIAAA9QABAiAaAAQAOAAAFgJQAHgIAAgRIAAg9IALAAIAAA9QAAAsglAAQgnAAABgsgAhXAJIAAg9IAMAAIAAA9QAAAiAaAAQAOAAAGgJQAGgIAAgRIAAg9IALAAIAAA9QABAsgmAAQgmAAAAgsgAihAmQgMgPABgXQgBgXAMgPQAMgQATAAQAVAAANARIgKAHQgFgHgFgDQgGgDgIAAQgOAAgIAMQgJANAAASQAAATAJAMQAJAMANAAQAPAAALgOIAIAHQgNARgVAAQgUAAgLgPgAluAnIAHgIQANAMAPAAQAKAAAHgFQAFgEAAgJQAAgIgEgEQgGgFgOgFQgSgFgGgHQgHgHAAgLQABgNAIgGQAJgIAPAAQASABAOAKIgHAJQgMgJgNAAQgLAAgFAFQgFAEAAAHQAAAHAEADQAFAFAQAFQARAHAHAGQAGAHABAMQAAAMgKAIQgJAIgQAAQgWAAgNgOgAoSAmQgMgPABgXQgBgXAMgPQAMgQATAAQAVAAAMARIgJAHQgFgHgFgDQgGgDgIAAQgOAAgIAMQgJANAAASQAAATAJAMQAJAMANAAQAbAAAAggIAAAAIgTAAIAAgLIAfAAIAAAKQAAAVgMAMQgKAKgRAAQgUAAgLgPgAqFAmQgLgPAAgXQAAgXALgPQAMgQATAAQAWAAALARIgJAHQgFgHgFgDQgGgDgIAAQgNAAgKAMQgIANAAASQAAATAJAMQAIAMAOAAQAbAAAAggIAAAAIgTAAIAAgLIAfAAIAAAKQgBAVgKAMQgLAKgRAAQgUAAgLgPgAIFA0IAAhoIA/AAIAAAKIgzAAIAAAhIAeAAIAAAKIgeAAIAAApIA2AAIAAAKgAG7A0IAAhoIALAAIAABeIA0AAIAAAKgAFpA0IAAhoIAmAAQAOAAAHAGQAIAHAAANQAAAQgPAGQAUAEAAAVQAAAfgiAAgAF1AqIAaAAQAXgBAAgTQgBgKgFgGQgHgFgKAAIgaAAgAF1gJIAZAAQASAAAAgRQAAgQgRAAIgaAAgAFUA0IgJgaIgsAAIgJAaIgMAAIAkhoIAOAAIAkBogAFHAPIgSg2IgTA2IAlAAgADGA0IAAhoIALAAIAABeIA1AAIAAAKgAi+A0IgJgaIgrAAIgJAaIgNAAIAlhoIANAAIAkBogAjLAPIgSg2IgSA2IAkAAgAl/A0IgJgaIgsAAIgJAaIgMAAIAlhoIANAAIAlBogAmLAPIgSg2IgTA2IAlAAgAo1A0IAAhoIALAAIAABog");
	this.shape_1.setTransform(73.2,10.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAWgMIgGgRIAABRIgLAAIAAhoIAOAAIAYA+IAHAUIAhhSIANAAIAABoIgLAAIAAhRQgBAFgGAMIgcBCgAJjAnIAIgIQANAMAPAAQALAAAFgFQAHgEAAgJQAAgIgGgEQgFgFgPgFQgRgFgGgHQgGgHAAgLQgBgNAKgGQAIgIAPAAQASABAOAKIgIAJQgMgJgNAAQgKAAgFAFQgFAEAAAHQAAAHAFADQAEAFAQAFQARAHAHAGQAGAHAAAMQAAAMgJAIQgJAIgRAAQgVAAgOgOgABxAJIAAg9IAMAAIAAA9QAAAiAbAAQANAAAHgJQAFgIAAgRIAAg9IAMAAIAAA9QAAAsgmAAQglAAgBgsgAhXAJIAAg9IAMAAIAAA9QAAAiAbAAQANAAAGgJQAGgIAAgRIAAg9IALAAIAAA9QAAAsglAAQgmAAAAgsgAikAmQgLgPAAgXQAAgXALgPQANgQASAAQAVAAAMARIgJAHQgFgHgFgDQgGgDgIAAQgNAAgKAMQgIANAAASQAAATAJAMQAIAMAOAAQAPAAALgOIAIAHQgNARgVAAQgTAAgMgPgAl7AnIAIgIQANAMAPAAQALAAAFgFQAHgEAAgJQAAgIgGgEQgFgFgOgFQgSgFgGgHQgHgHABgLQAAgNAJgGQAIgIAPAAQASABAOAKIgIAJQgMgJgNAAQgKAAgFAFQgFAEAAAHQAAAHAEADQAGAFAPAFQARAHAHAGQAGAHAAAMQAAAMgJAIQgKAIgQAAQgUAAgPgOgAokAmQgMgPAAgXQAAgXAMgPQANgQASAAQAWAAAMARIgJAHQgGgHgFgDQgGgDgIAAQgOAAgJAMQgIANAAASQAAATAJAMQAJAMANAAQAbAAAAggIAAAAIgSAAIAAgLIAdAAIAAAKQABAVgMAMQgKAKgRAAQgTAAgMgPgAqdAmQgLgPAAgXQAAgXALgPQAMgQATAAQAWAAALARIgJAHQgFgHgFgDQgGgDgIAAQgNAAgKAMQgIANAAASQAAATAJAMQAIAMAOAAQAbAAAAggIAAAAIgTAAIAAgLIAfAAIAAAKQgBAVgKAMQgLAKgRAAQgUAAgLgPgAIaA0IAAhoIA/AAIAAAKIgzAAIAAAhIAeAAIAAAKIgeAAIAAApIA2AAIAAAKgAHNA0IAAhoIALAAIAABeIA1AAIAAAKgAF4A0IAAhoIAnAAQANAAAHAGQAIAHAAANQAAAQgPAGQAUAEAAAVQAAAfgiAAgAGEAqIAbAAQAVgBABgTQAAgKgHgGQgFgFgLAAIgaAAgAGEgJIAZAAQATAAgBgRQAAgQgQAAIgbAAgAFgA0IgJgaIgsAAIgJAaIgMAAIAkhoIAOAAIAkBogAFTAPIgSg2IgTA2IAlAAgADPA0IAAhoIAMAAIAABeIA0AAIAAAKgAjEA0IgJgaIgrAAIgJAaIgNAAIAlhoIANAAIAkBogAjRAPIgSg2IgSA2IAkAAgAmOA0IgJgaIgsAAIgJAaIgLAAIAkhoIANAAIAlBogAmaAPIgSg2IgTA2IAlAAgApKA0IAAhoIAMAAIAABog");
	this.shape_2.setTransform(75.6,10.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAZgMIgGgRIAABRIgLAAIAAhoIAOAAIAYA+IAHAUIAhhSIANAAIAABoIgLAAIAAhRQgBAFgGAMIgcBCgAJ8AnIAHgIQANAMAPAAQAKAAAHgFQAFgEAAgJQAAgIgEgEQgGgFgPgFQgQgFgHgHQgGgHgBgLQAAgNAJgGQAJgIAPAAQASABAOAKIgIAJQgLgJgNAAQgLAAgFAFQgFAEAAAHQAAAHAFADQAFAFAPAFQARAHAHAGQAHAHAAAMQAAAMgKAIQgKAIgPAAQgWAAgNgOgAB3AJIAAg9IANAAIAAA9QgBAiAbAAQANAAAHgJQAFgIABgRIAAg9IALAAIAAA9QAAAsglAAQgnAAAAgsgAhXAJIAAg9IAMAAIAAA9QAAAiAbAAQANAAAGgJQAGgIAAgRIAAg9IAMAAIAAA9QAAAsgmAAQgmAAAAgsgAinAmQgMgPAAgXQAAgXAMgPQANgQASAAQAWAAAMARIgJAHQgGgHgFgDQgGgDgIAAQgOAAgJAMQgIANAAASQAAATAJAMQAJAMANAAQAQAAAKgOIAIAHQgNARgVAAQgTAAgMgPgAmGAnIAHgIQANAMAPAAQALAAAFgFQAHgEgBgJQAAgIgEgEQgGgFgPgFQgQgFgHgHQgGgHgBgLQAAgNAJgGQAJgIAPAAQASABAOAKIgIAJQgMgJgMAAQgLAAgFAFQgFAEAAAHQAAAHAFADQAEAFAQAFQARAHAHAGQAHAHgBAMQABAMgKAIQgKAIgPAAQgVAAgOgOgAo2AmQgLgPAAgXQAAgXALgPQANgQASAAQAVAAAMARIgJAHQgFgHgFgDQgGgDgIAAQgNAAgKAMQgIANAAASQAAATAJAMQAIAMAOAAQAbAAAAggIAAAAIgSAAIAAgLIAeAAIAAAKQgBAVgKAMQgLAKgRAAQgTAAgMgPgAq1AmQgLgPAAgXQAAgXALgPQAMgQATAAQAWAAALARIgJAHQgFgHgFgDQgGgDgIAAQgNAAgKAMQgIANAAASQAAATAJAMQAIAMAOAAQAbAAAAggIAAAAIgTAAIAAgLIAfAAIAAAKQgBAVgKAMQgLAKgRAAQgUAAgLgPgAIvA0IAAhoIA/AAIAAAKIgzAAIAAAhIAeAAIAAAKIgeAAIAAApIA2AAIAAAKgAHfA0IAAhoIAMAAIAABeIAzAAIAAAKgAGIA0IAAhoIAmAAQANAAAHAGQAIAHAAANQAAAQgPAGQAUAEAAAVQAAAfgiAAgAGTAqIAbAAQAWgBgBgTQAAgKgFgGQgHgFgKAAIgaAAgAGTgJIAaAAQARAAABgRQgBgQgQAAIgbAAgAFsA0IgJgaIgsAAIgJAaIgMAAIAkhoIAOAAIAkBogAFfAPIgSg2IgTA2IAlAAgADYA0IAAhoIALAAIAABeIA0AAIAAAKgAjKA0IgJgaIgrAAIgJAaIgNAAIAlhoIANAAIAlBogAjXAPIgSg2IgSA2IAkAAgAmdA0IgJgaIgsAAIgJAaIgMAAIAlhoIANAAIAlBogAmpAPIgSg2IgTA2IAlAAgApfA0IAAhoIAMAAIAABog");
	this.shape_3.setTransform(78,10.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAdgMIgHgRIAABRIgLAAIAAhoIAOAAIAYA+IAHAUIAhhSIANAAIAABoIgLAAIAAhRQgBAFgGAMIgcBCgAKTAnIAIgIQANAMAPAAQAKAAAHgFQAFgEABgJQgBgIgFgEQgFgFgOgFQgRgFgHgHQgHgHAAgLQABgNAIgGQAJgIAPAAQASABAOAKIgHAJQgMgJgOAAQgKAAgFAFQgFAEAAAHQAAAHAEADQAGAFAPAFQARAHAHAGQAGAHABAMQAAAMgKAIQgJAIgRAAQgVAAgOgOgAB+AJIAAg9IALAAIAAA9QABAiAaAAQAOAAAFgJQAHgIAAgRIAAg9IALAAIAAA9QAAAsglAAQgnAAABgsgAhXAJIAAg9IAMAAIAAA9QAAAiAaAAQAOAAAGgJQAGgIAAgRIAAg9IALAAIAAA9QABAsgmAAQgmAAAAgsgAiqAmQgMgPABgXQgBgXAMgPQAMgQATAAQAVAAANARIgKAHQgFgHgFgDQgGgDgIAAQgOAAgIAMQgJANAAASQAAATAJAMQAJAMANAAQAPAAALgOIAIAHQgNARgVAAQgUAAgLgPgAmTAnIAIgIQANAMAPAAQAKAAAHgFQAFgEAAgJQAAgIgEgEQgGgFgOgFQgSgFgGgHQgHgHAAgLQABgNAIgGQAJgIAPAAQASABAOAKIgHAJQgMgJgNAAQgLAAgFAFQgFAEAAAHQAAAHAEADQAFAFAQAFQARAHAHAGQAGAHABAMQAAAMgKAIQgJAIgQAAQgWAAgOgOgApIAmQgMgPABgXQgBgXAMgPQAMgQATAAQAVAAANARIgKAHQgFgHgFgDQgGgDgIAAQgOAAgIAMQgJANAAASQAAATAJAMQAJAMANAAQAbAAAAggIAAAAIgTAAIAAgLIAfAAIAAAKQAAAVgMAMQgKAKgRAAQgUAAgLgPgArNAmQgLgPAAgXQAAgXALgPQAMgQATAAQAWAAALARIgJAHQgFgHgFgDQgGgDgIAAQgNAAgKAMQgIANAAASQAAATAJAMQAIAMAOAAQAbAAAAggIAAAAIgTAAIAAgLIAfAAIAAAKQgBAVgKAMQgLAKgRAAQgUAAgLgPgAJEA0IAAhoIA/AAIAAAKIgzAAIAAAhIAeAAIAAAKIgeAAIAAApIA2AAIAAAKgAHxA0IAAhoIALAAIAABeIA0AAIAAAKgAGWA0IAAhoIAmAAQAOAAAHAGQAIAHAAANQAAAQgPAGQAUAEAAAVQAAAfgiAAgAGiAqIAaAAQAXgBAAgTQgBgKgGgGQgGgFgKAAIgaAAgAGigJIAZAAQASAAAAgRQAAgQgRAAIgaAAgAF4A0IgJgaIgsAAIgJAaIgMAAIAkhoIAOAAIAkBogAFrAPIgSg2IgTA2IAlAAgADhA0IAAhoIALAAIAABeIA1AAIAAAKgAjQA0IgJgaIgrAAIgJAaIgNAAIAlhoIANAAIAlBogAjdAPIgSg2IgSA2IAkAAgAmsA0IgJgaIgsAAIgJAaIgMAAIAlhoIANAAIAlBogAm4APIgSg2IgTA2IAlAAgAp0A0IAAhoIALAAIAABog");
	this.shape_4.setTransform(80.4,10.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},2).to({state:[{t:this.shape_2}]},2).to({state:[{t:this.shape_3}]},2).to({state:[{t:this.shape_4}]},2).to({state:[{t:this.shape_3}]},2).to({state:[{t:this.shape_2}]},2).to({state:[{t:this.shape_1}]},2).wait(2));

	// Capa_2
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#02C2FD").s().p("AqyBSIAAijIVlAAIAACjg");
	this.shape_5.setTransform(70.7,10.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#02C2FD").s().p("ArKBSIAAijIWWAAIAACjg");
	this.shape_6.setTransform(73.2,10.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#02C2FD").s().p("ArkBSIAAijIXJAAIAACjg");
	this.shape_7.setTransform(75.7,10.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#02C2FD").s().p("Ar1BSIAAijIXrAAIAACjg");
	this.shape_8.setTransform(77.5,10.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#02C2FD").s().p("AsQBSIAAijIYhAAIAACjg");
	this.shape_9.setTransform(80.2,10.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#02C2FD").s().p("ArGBSIAAijIWNAAIAACjg");
	this.shape_10.setTransform(72.9,10.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5}]}).to({state:[{t:this.shape_6}]},2).to({state:[{t:this.shape_7}]},2).to({state:[{t:this.shape_8,p:{scaleX:1,x:77.5}}]},2).to({state:[{t:this.shape_9,p:{scaleX:1,x:80.2}}]},2).to({state:[{t:this.shape_9,p:{scaleX:0.965,x:77.5}}]},2).to({state:[{t:this.shape_8,p:{scaleX:0.972,x:75.4}}]},2).to({state:[{t:this.shape_10}]},2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1.6,2.1,138.3,16.4);


(lib._04 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_23 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(23).call(this.frame_23).wait(1));

	// Capa_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AD3AsQgNgSAAgaQAAgZANgRQAOgRAVAAQAWAAANARQAOARAAAZQAAAagOARQgNARgWAAQgVAAgOgQgAEBgiQgKANAAAVQAAAVALAOQAJANAQAAQAPAAAKgNQAKgNAAgWQAAgUgKgOQgKgNgQAAQgPAAgKANgAA/AsIAJgKQAOAOAQAAQAMAAAHgFQAGgFAAgKQAAgIgGgFQgGgGgPgFQgTgGgIgHQgHgIAAgMQAAgOAKgIQAKgIAQAAQAUAAAQAMIgIAKQgOgKgOAAQgLAAgGAFQgGAFAAAHQAAAIAFAEQAGAFARAGQATAHAHAHQAHAIAAANQAAAOgKAJQgKAJgSAAQgXAAgQgQgAgeALIAAhEIANAAIAABEQAAAlAcAAQAPAAAHgJQAGgJAAgTIAAhEIANAAIAABEQAAAxgpAAQgpAAAAgxgAh7AgIAMgEQAIAUARAAQAOAAAHgIQAGgIAAgTIAAhGIAMAAIAABHQAAAugnAAQgbAAgKgcgAjvAsQgNgSAAgaQAAgZANgRQAOgRAVAAQAWAAANARQAOARAAAZQAAAagOARQgNARgWAAQgVAAgOgQgAjlgiQgKANAAAVQAAAVALAOQAJANAQAAQAPAAAKgNQAKgNAAgWQAAgUgKgOQgKgNgQAAQgPAAgKANgAC1A6IAAhnIgiAAIAAgMIBSAAIAAAMIgjAAIAABngAlKA6IAAhzIANAAIAABnIA6AAIAAAMg");
	this.shape.setTransform(169.7,12.9);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(15).to({_off:false},0).wait(9));

	// Capa_3
	this.instance = new lib.Símbolo4();
	this.instance.parent = this;
	this.instance.setTransform(122.7,13,0.912,0.912,0,0,0,8.4,6.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:122.6,y:12.9},0).wait(23));

	// Capa 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF5900").s().p("AoQBfIAAi8IPGAAQAIgBAKAFQAIAEAGAFIA3BCQAEAGAAAHQACAIgGAHIg3BCIgOALQgKADgIABg");
	this.shape_1.setTransform(161.2,12.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(24));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(108.3,3.4,105.9,18.9);


(lib.grande = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_234 = function() {
		this.gotoAndPlay(0);
		
		// 3 loops
		if (!this.looped) this.looped = 1;
		if (this.looped++ == 3) this.gotoAndStop(210);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(234).call(this.frame_234).wait(1));

	// Capa 5
	this.instance = new lib._04();
	this.instance.parent = this;
	this.instance.setTransform(388.3,617.1,0.972,0.972,0,0,0,164.1,12.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(167).to({_off:false},0).wait(1).to({regX:161.2,x:388.1,y:617},0).wait(1).to({x:390.7},0).wait(1).to({x:393.3},0).wait(1).to({x:395.9},0).wait(1).to({x:398.6},0).wait(1).to({x:401.2},0).wait(1).to({x:403.8},0).wait(1).to({x:406.4},0).wait(60));

	// Capa 9
	this.instance_1 = new lib.Símbolo8();
	this.instance_1.parent = this;
	this.instance_1.setTransform(253,557.4,1.634,1.634,0,0,0,-8.2,16.4);

	this.instance_2 = new lib.Símbolo15();
	this.instance_2.parent = this;
	this.instance_2.setTransform(253.1,485.1,1.634,1.634,0,0,0,-5.4,16.1);

	this.instance_3 = new lib.Símbolo6();
	this.instance_3.parent = this;
	this.instance_3.setTransform(253,440.7,1.634,1.634,0,0,0,0.7,29.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3,p:{scaleX:1.634,scaleY:1.634,x:253,y:440.7}},{t:this.instance_2,p:{scaleX:1.634,scaleY:1.634,x:253.1,y:485.1}},{t:this.instance_1,p:{scaleX:1.634,scaleY:1.634,x:253,y:557.4}}]},106).to({state:[{t:this.instance_3,p:{scaleX:1,scaleY:1,x:355.7,y:451.1}},{t:this.instance_2,p:{scaleX:1,scaleY:1,x:355.7,y:478.3}},{t:this.instance_1,p:{scaleX:1,scaleY:1,x:355.6,y:522.5}}]},38).wait(91));

	// Capa_2
	this.instance_4 = new lib.pacumulables();
	this.instance_4.parent = this;
	this.instance_4.setTransform(353.7,582.7,0.941,0.941);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(154).to({_off:false},0).wait(81));

	// Capa_8
	this.instance_5 = new lib.pacumulables();
	this.instance_5.parent = this;
	this.instance_5.setTransform(264.2,603.6,0.768,0.768,0,0,0,66.2,10.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AAhAEQgLgZgFgQIAADFIgaAAIAAj8IAfAAIA8CWQANAjAEAOIBNjHIAfAAIAAD8IgbAAIAAjFIgPApIhDCigAENB/QgdgkAAg6QAAg4AdgkQAdgkAuAAQAvAAAdAkQAdAjAAA5QAAA5geAlQgcAkgwAAQguAAgcgkgAEigpQgXAcAAAuQAAAvAYAdQAVAcAhAAQAhAAAVgbQAVgdAAgwQAAgugWgcQgVgdgiAAQghAAgUAdgAkgB/QgdgkAAg6QAAg4AdgkQAdgkAuAAQAvAAAdAkQAdAjAAA5QAAA5gdAlQgdAkgwAAQguAAgcgkgAkLgpQgXAcAAAuQAAAvAXAdQAWAcAhAAQAgAAAWgbQAVgdAAgwQAAgugWgcQgVgdgiAAQgiAAgTAdgAq+B/QgcgkAAg6QAAg4AcgkQAegkAuAAQAvAAAdAkQAdAjAAA5QAAA5geAlQgcAkgvAAQgvAAgdgkgAqpgpQgVAcAAAuQAAAvAWAdQAWAcAhAAQAhAAAVgbQAVgdAAgwQAAgugWgcQgVgdghAAQgiAAgVAdgAuZCAIASgVQAgAeAkAAQAYAAAOgLQAPgMAAgUQAAgRgNgMQgMgMgjgMQgpgPgPgPQgQgPAAgbQAAgdAWgSQAVgRAkAAQAqAAAiAbIgSAVQgdgXggAAQgXAAgNALQgMAKAAARQAAARALAJQAMAKAkANQAqAPAQARQAPAQAAAcQAAAegWATQgWAVgnAAQgyAAgigjgAMBCgIAAj8IAcAAIAADhIB9AAIAAAbgAK5CgIAAj8IAcAAIAAD8gAInCgIhVj8IAdAAIBIDdIBIjdIAcAAIhVD8gAnrCgIAAj8IAdAAIAADhIB8AAIAAAbgAFJhsIAmg5IAlAAIg2A5gAqBhsIAlg5IAmAAIg2A5g");
	this.shape.setTransform(420.9,601.2);

	this.instance_6 = new lib.Símbolo12();
	this.instance_6.parent = this;
	this.instance_6.setTransform(364.4,507.2,2.158,2.158,0,0,0,69.8,35.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6},{t:this.shape},{t:this.instance_5}]},61).to({state:[]},45).wait(129));

	// Capa_12
	this.instance_7 = new lib.Símbolo3();
	this.instance_7.parent = this;
	this.instance_7.setTransform(355.7,521.3,0.999,0.999,12.3,0,0,-4,7.5);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(22).to({_off:false},0).wait(1).to({regX:66.1,regY:14.2,scaleX:1,scaleY:1,rotation:11.3,x:423.1,y:541.6},0).wait(1).to({rotation:10.2,x:423.5,y:540.3},0).wait(1).to({rotation:9.1,x:423.9,y:538.9},0).wait(1).to({rotation:7.9,x:424.2,y:537.6},0).wait(1).to({rotation:6.8,x:424.5,y:536.2},0).wait(1).to({rotation:5.7,x:424.8,y:534.9},0).wait(1).to({rotation:4.5,x:425.1,y:533.5},0).wait(1).to({rotation:3.4,x:425.3,y:532.2},0).wait(1).to({rotation:2.3,x:425.5,y:530.8},0).wait(1).to({rotation:1.1,x:425.7,y:529.4},0).wait(1).to({rotation:0,x:425.8,y:528},0).wait(27).to({_off:true},1).wait(174));

	// Capa_2 copia
	this.instance_8 = new lib.Símbolo2();
	this.instance_8.parent = this;
	this.instance_8.setTransform(355.7,487.1,0.999,0.999,12.3,0,0,-4.9,30.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1).to({regX:53.1,regY:45.7,scaleX:1,scaleY:1,rotation:11.3,x:409.6,y:513.2},0).wait(1).to({rotation:10.2,x:410.1,y:512.2},0).wait(1).to({rotation:9.1,x:410.6,y:511.1},0).wait(1).to({rotation:7.9,x:411.1,y:510},0).wait(1).to({rotation:6.8,x:411.5,y:508.9},0).wait(1).to({rotation:5.7,x:411.9,y:507.8},0).wait(1).to({rotation:4.5,x:412.3,y:506.7},0).wait(1).to({rotation:3.4,x:412.7,y:505.5},0).wait(1).to({rotation:2.3,x:413,y:504.4},0).wait(1).to({rotation:1.1,x:413.4,y:503.3},0).wait(1).to({rotation:0,x:413.7,y:502.1},0).wait(49).to({_off:true},1).wait(174));

	// Capa_7
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF5900").s().p("ADMCrQgIgIAAgKQAAgMAIgIQADgBACgCIAAgxQAAgFgGAAQgggCgSgOQgUgRAAgbIAAhqIAnAAIAABlQAAAPAJAHQAKAKAdAAIAPAAQAaAAAMgKQAGgHAAgPIAAhlIAoAAIAABqQAAAbgTARQgRAOgkACQgEAAgBAFIAAAyQABAAABABQAAAAABAAQAAABAAAAQABAAAAAAQAJAIAAAMQAAAKgJAIQgJAIgMAAQgLAAgKgIgAHEBQQgfAAgTgGQgKgDgHgEQgcgSABgmIAAgjQgBgoAcgSQAHgFAKgDQATgFAfAAIAWAAQAvAAAXANQAaASAAAoIAAAjQAAAmgaASQgXANgvAAgAGbg3QgIADgBAHQgEAHAAAQIAAAgQAAANAEAFQABAIAIAEQAKAIAXAAIAnAAQAXAAALgIQAOgHgBgXIAAggQABgYgOgJQgLgJgXAAIgnAAQgXAAgKAJgAoCBPQgTgDgJgCQgbgNAAgjIAAgCIAmAAQABAMAGAFQAHAHARAAIA6AAQAdAAAJgFQAHgDAAgNIAAgBQAAgKgDgFQgHgEgSAAIhRAAQggAAgOgKQgOgLAAgaIAAgJQAAgZASgJQAPgJAjgDIAUAAIAoAAQAsAAASAMQAMAKABAUIAAAIIglAAQgBgKgIgEQgKgFgUAAIguAAIgNABQgPAAgGAEQgIABAAANIAAAFQAAAHAEAGQAFADASAAIBFAAQAlAAAQAJQAWALAAAfQAAAigaANQgPAGgpAAgAA2BPIAAhvQAAgfgvAAIgLAAQgsAAAAAfIAABvIgoAAIAAhvQAAgNgIgIQgMgKgYAAIgPAAQgsAAAAAfIAABvIgqAAIAAhwQAAgfAXgPQASgQAlAAIAfAAQAhAAAXAQQAVgQAiAAIAeAAQAjAAATAQQAUAPAAAfIAABwgAk7BPIAAipIApAAIAACpgAk8iEQgIgJAAgMQAAgNAIgHQAIgFAMAAQAIAAAFADIAJACQAIAHAAANQAAAMgIAJIgJAFQgFACgIAAQgMAAgIgHg");
	this.shape_1.setTransform(412,653.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(235));

	// Capa_10
	this.instance_9 = new lib.chico800();
	this.instance_9.parent = this;
	this.instance_9.setTransform(190,428,0.332,0.332);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(235));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(190,428,279.2,265.8);


// stage content:
(lib._300x250grande = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		//this.stop();
		//screenad.log('done');
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2).p("A3bzhMAu3AAAMAAAAnDMgu3AAAg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Background
	this.instance = new lib.grande();
	this.instance.parent = this;
	this.instance.setTransform(61.2,-30.2,1,1,0,0,0,275,400);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(126.2,122.8,324.9,265.8);
// library properties:
lib.properties = {
	id: '07EC81650E5FAD4E8F90E0389E2B117E',
	width: 300,
	height: 250,
	fps: 24,
	color: "#C2C2C2",
	opacity: 1.00,
	manifest: [
		{src:"./chico800.png?1551438013591", id:"chico800"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['07EC81650E5FAD4E8F90E0389E2B117E'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;