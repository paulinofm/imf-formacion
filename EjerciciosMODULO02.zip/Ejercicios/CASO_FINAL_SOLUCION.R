#carga de librerias
#install.packages(missForest,, dependencies = TRUE)
library(missForest) #para valores NA
library(ggplot2) 
library(ROCR)   # para curva ROC
library(glmnet) # para regresion
library(gridExtra) #para dibujar matriz de graficos
library(dplyr)
library(caret) #Para sensitividad y especificidad

set.seed(1000)

# Leemos los datos del CSV en R
CASO_FINAL_crx.data <- read.csv(file="/home/fermasolar/Documentos/MODULO02/Ejercicios/CASO_FINAL_crx.data", na.strings=c("?"," ") ,header=FALSE, sep="," )

head(CASO_FINAL_crx.data,n=20)

str(CASO_FINAL_crx.data)

#Relleno de valores perdidos con la libreria missForest
#valores vacios
#Contar numero de filas que tienen al menos un valor nulo
porcentajeNA <- (nrow(CASO_FINAL_crx.data)-nrow(CASO_FINAL_crx.data[rowSums(is.na(CASO_FINAL_crx.data))==0,]))/nrow(CASO_FINAL_crx.data) *100
porcentajeNA # --> 5.36%

#aplicamos librería missForest
datos_completos <- missForest(CASO_FINAL_crx.data)$ximp
head(datos_completos)
porcentajeNA <- (nrow(datos_completos)-nrow(datos_completos[rowSums(is.na(datos_completos))==0,]))/nrow(datos_completos) *100
porcentajeNA # --> 0.0%
summary(datos_completos)
str(datos_completos)

#cambiamos la variable V16 a valor num?rico 0/1 en vez de -/+
datos_completos$V16 <- as.numeric(datos_completos$V16)-1

#dibujar las variables
graficos_caja <- c()
for(i in 1:15) {
  if (is.factor(CASO_FINAL_crx.data[,i])) {
    graficos_caja[[i]] <- CASO_FINAL_crx.data %>% ggplot(aes_string(x = CASO_FINAL_crx.data[,i])) + geom_bar(aes(fill = V16), position = "dodge") # dividimos A16 por color
  }else {
    graficos_caja[[i]] <- CASO_FINAL_crx.data %>% ggplot(aes(x = CASO_FINAL_crx.data$V16)) + geom_boxplot(aes_string(y = CASO_FINAL_crx.data[,i], fill = "V16"))
  }
}

grid.arrange(grobs = graficos_caja, ncol = 5, top = "Distribución de las variables")

#Dividimos el dataset tomando las primeras 590 instancias como train y las ?ltimas 100 como test.
datostrain <- datos_completos[1:590,]
datostest <- datos_completos[591:690, ]

predictores <- datostrain[, 1:15 ]
predictora <- datostrain$V16

predictoresTest <- datostest[, 1:15 ]
predictoraTest <- datostest$V16

#ENTRENAMIENTO DEL MODELO CON RIDGE Y LASSO
X_modeloTrain <- model.matrix(predictora~.,predictores )[,-1]
str(X_modeloTrain)
#summary(X_modeloTrain)
Y_modeloTrain <- predictora

X_modeloTest <- model.matrix(predictoraTest~.,predictoresTest)[,-1]

#Parametro lambda ?? = 10^10 to ?? = 10^???2,
grid =10^ seq (10,-2, length =100)

#Parametro de validacion cruzada : 
n_folds=5

#RIDGE
ridge.modelo =cv.glmnet (X_modeloTrain,Y_modeloTrain,alpha =0,family="binomial", type.measure="auc", lambda =grid, nfolds = n_folds) 
#plot(ridge.modelo)

#curva ROC
prediccion_ridge <- predict.glmnet(ridge.modelo$glmnet.fit, newx=X_modeloTest, s=ridge.modelo$lambda.min)
dim(prediccion_ridge)
confusion_matrix <- ifelse(prediccion_ridge > 0.5,'1','0')
table(confusion_matrix, predictoraTest)

#LASSO
lasso.modelo =cv.glmnet (X_modeloTrain,Y_modeloTrain,alpha=1,  family="binomial",type.measure='auc', lambda =grid, nfolds = n_folds)
lasso.modelo$lambda.min
prediccion_lasso <- predict.glmnet(lasso.modelo$glmnet.fit, newx=X_modeloTest, s=lasso.modelo$lambda.min)
confusion_matrix <- ifelse(prediccion_ridge > 0.5,'1','0')
matriz_confusion<-table(confusion_matrix, predictoraTest)
str(matriz_confusion)
#plot(lasso.modelo)



pr_rigge <- prediction(prediccion_ridge, predictoraTest)
prf_ridge <- performance(pr_rigge, measure = "tpr", x.measure = "fpr")
auc_ridge= as.numeric(performance(pr_rigge,"auc")@y.values)
auc_ridge #Area bajo la curva
plot(prf_ridge,main = "Ridge")

pr_lasso <- prediction(prediccion_lasso, predictoraTest)
prf_lasso <- performance(pr_lasso, measure = "tpr", x.measure = "fpr")
auc_lasso= as.numeric(performance(pr_lasso,"auc")@y.values)
auc_lasso #Area bajo la curva
plot(prf_lasso,main = "Lasso")

#LOG ODDS
coeficientes <- coef(lasso.modelo)
coeficientes
num_coef_no_cero <- sum(coeficientes!=0)
num_coef_no_cero

#Si por cada verdadero positivo ganamos 100e y por cada falso positivo perdemos 20e. 
#¿ Qué rentabilidad aporta aplicar este modelo?
y_pred_lasso <- as.numeric(predict.glmnet(lasso.modelo$glmnet.fit, newx=X_modeloTest, s=lasso.modelo$lambda.min)>.5)
conf_matrix <- confusionMatrix(as.factor(y_pred_lasso), as.factor(predictoraTest), mode = "everything", positive = "1")
conf_matrix

sensibilidad <- conf_matrix$byClass["Sensitivity"]
sensibilidad
especificidad <-conf_matrix$byClass["Specificity"]
especificidad
rent_esp <- ((sensibilidad*100) - (especificidad*20))
rent_esp

##############################################################################################